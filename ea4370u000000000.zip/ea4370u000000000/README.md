# Tend — Sustainable Urban Farming

A Vue 3 application for viewing registered urban plots and recording manual crop inspections.

## Features

- Responsive plot grid with monitoring dates and inspection actions.
- Inspection registration with required fields and plot existence checks.
- Inspection actions disabled before a plot's monitoring start date.
- Success and critical-status notifications.
- English and Spanish interface; English is the default.
- Lazy-loaded Home, inspection registration and page-not-found routes.

## Technology

Vue 3, Vite, Vue Router, Vue I18n, PrimeVue with Aura, PrimeFlex,
PrimeIcons, Axios and json-server 0.17.4.

## Local development

Requires Node.js 20.19+ or 22.12+.

1. Install dependencies: npm install
2. Start the mock API: npm run server
3. In another terminal, start the frontend: npm run dev
4. Open the local URL displayed by Vite.

The API runs at http://localhost:3000. Edit .env if its address changes.
To check compilation, run npm run build.

## API resources

- GET /plots
- GET /plots/:id
- POST /inspections

The supplied server/db.json contains illustrative plots. Replace it with the
exam's original file if that file is available.

## Note on the logo

The historic assignment specifies the public Clearbit Logo API. That service
was discontinued after the exam was written. The toolbar tries the configured
URL and displays a Tend lettermark if the image fails to load.

## Author

Alex Rivera
