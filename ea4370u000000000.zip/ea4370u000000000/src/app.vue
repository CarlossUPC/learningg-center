<script setup>
/**
 * Displays the shared navigation and the currently selected page.
 * @summary Defines the root application layout.
 * @author Alex Rivera
 */
import AppToolbar from '@/shared/presentation/components/app-toolbar.component.vue';
</script>

<template>
  <div class="app-shell">
    <app-toolbar />
    <main id="main-content" class="page-container" tabindex="-1">
      <router-view v-slot="{ Component }">
        <component :is="Component" :key="$route.fullPath" />
      </router-view>
    </main>
    <pv-toast position="top-right" />
  </div>
</template>
