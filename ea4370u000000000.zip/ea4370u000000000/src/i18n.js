/**
 * Provides the application's English and Spanish messages.
 * @summary Initializes Vue I18n with English as the default language.
 * @author Alex Rivera
 */
import { createI18n } from 'vue-i18n';
import en from './locales/en.json';
import es from './locales/es.json';

export default createI18n({
  legacy: false,
  locale: 'en',
  fallbackLocale: 'en',
  messages: { en, es }
});
