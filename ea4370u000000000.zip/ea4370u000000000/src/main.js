/**
 * Registers the application plugins and prefixed PrimeVue components.
 * @summary Initializes the Tend Vue application.
 * @author Alex Rivera
 */
import { createApp } from 'vue';
import PrimeVue from 'primevue/config';
import Aura from '@primeuix/themes/aura';
import ToastService from 'primevue/toastservice';
import Button from 'primevue/button';
import Column from 'primevue/column';
import DataTable from 'primevue/datatable';
import InputText from 'primevue/inputtext';
import Select from 'primevue/select';
import SelectButton from 'primevue/selectbutton';
import Textarea from 'primevue/textarea';
import Toast from 'primevue/toast';
import Toolbar from 'primevue/toolbar';
import 'primeflex/primeflex.css';
import 'primeicons/primeicons.css';
import './style.css';
import App from './app.vue';
import router from './router.js';
import i18n from './i18n.js';

createApp(App)
  .use(PrimeVue, {
    theme: { preset: Aura, options: { darkModeSelector: 'none' } },
    ripple: true
  })
  .use(ToastService)
  .use(router)
  .use(i18n)
  .component('pv-button', Button)
  .component('pv-column', Column)
  .component('pv-data-table', DataTable)
  .component('pv-input-text', InputText)
  .component('pv-select', Select)
  .component('pv-select-button', SelectButton)
  .component('pv-textarea', Textarea)
  .component('pv-toast', Toast)
  .component('pv-toolbar', Toolbar)
  .mount('#app');
