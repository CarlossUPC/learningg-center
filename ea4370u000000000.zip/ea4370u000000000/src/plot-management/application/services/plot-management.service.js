/**
 * Coordinates plot retrieval and inspection registration.
 * @summary Validates the plot before saving an inspection.
 * @author Alex Rivera
 */
import { Inspection } from '@/plot-management/domain/model/inspection.entity.js';
import { PlotApiService } from '@/plot-management/infrastructure/services/plot-api.service.js';
import { InspectionApiService } from '@/plot-management/infrastructure/services/inspection-api.service.js';

export class PlotManagementService {
  #plotApi = new PlotApiService();
  #inspectionApi = new InspectionApiService();

  getPlots() {
    return this.#plotApi.getAll();
  }

  async getPlotById(id) {
    const plotId = Number(id);
    if (!Number.isSafeInteger(plotId) || plotId < 1) {
      throw new Error('invalid-plot');
    }
    try {
      return await this.#plotApi.getById(plotId);
    } catch (error) {
      if (error.response?.status === 404) {
        throw new Error('invalid-plot');
      }
      throw error;
    }
  }

  async registerInspection(values) {
    const plot = await this.getPlotById(values.plotId);
    if (!plot.canRegisterInspection) {
      throw new Error('not-started');
    }
    const inspection = new Inspection({
      plotId: plot.id,
      observations: values.observations,
      recommendedActions: values.recommendedActions,
      cropStatus: values.cropStatus,
      inspectionDate: new Date().toISOString()
    });
    return this.#inspectionApi.create(inspection);
  }
}
