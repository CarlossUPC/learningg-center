/**
 * Enforces the required inspection fields and allowed crop statuses.
 * @summary Represents an inspection registered for a plot.
 * @author Alex Rivera
 */
export class Inspection {
  constructor({
    id = null,
    plotId,
    observations,
    recommendedActions,
    cropStatus,
    inspectionDate
  }) {
    const validStatuses = ['Good', 'Warning', 'Critical'];

    if (
      !Number.isSafeInteger(Number(plotId)) ||
      Number(plotId) < 1 ||
      !String(observations ?? '').trim() ||
      !String(recommendedActions ?? '').trim() ||
      !validStatuses.includes(cropStatus)
    ) {
      throw new Error('required-fields');
    }

    this.id = id === null ? null : Number(id);
    this.plotId = Number(plotId);
    this.observations = String(observations).trim();
    this.recommendedActions = String(recommendedActions).trim();
    this.cropStatus = cropStatus;
    this.inspectionDate = inspectionDate;
  }
}
