/**
 * Models a plot and its monitoring eligibility rule.
 * @summary Represents a registered urban plot.
 * @author Alex Rivera
 */
export class Plot {
  constructor({ id, name, location, hectares, monitoringStartDate }) {
    this.id = Number(id);
    this.name = String(name);
    this.location = String(location);
    this.hectares = Number(hectares);
    this.monitoringStartDate = String(monitoringStartDate);
  }

  get canRegisterInspection() {
    const datePart = this.monitoringStartDate.slice(0, 10);
    const [year, month, day] = datePart.split('-').map(Number);
    const startDate = new Date(year, month - 1, day);

    if (
      !year || !month || !day ||
      startDate.getFullYear() !== year ||
      startDate.getMonth() !== month - 1 ||
      startDate.getDate() !== day
    ) {
      return false;
    }

    const today = new Date();
    today.setHours(0, 0, 0, 0);
    return startDate <= today;
  }
}
