/**
 * Converts inspection entities to request resources and API responses back.
 * @summary Keeps the Inspection domain model independent of JSON payloads.
 * @author Alex Rivera
 */
import { Inspection } from '@/plot-management/domain/model/inspection.entity.js';

export class InspectionAssembler {
  toResourceFromEntity(inspection) {
    return {
      plotId: inspection.plotId,
      observations: inspection.observations,
      recommendedActions: inspection.recommendedActions,
      cropStatus: inspection.cropStatus,
      inspectionDate: inspection.inspectionDate
    };
  }

  toEntityFromResponse(response) {
    return new Inspection(response.data);
  }
}
