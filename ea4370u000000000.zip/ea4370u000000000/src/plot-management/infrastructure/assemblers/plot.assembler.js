/**
 * Converts Axios plot responses into domain entities.
 * @summary Isolates the Plot API representation from the domain model.
 * @author Alex Rivera
 */
import { Plot } from '@/plot-management/domain/model/plot.entity.js';

export class PlotAssembler {
  toEntityFromResource(resource) {
    return new Plot({
      id: resource.id,
      name: resource.name,
      location: resource.location,
      hectares: resource.hectares,
      monitoringStartDate: resource.monitoringStartDate
    });
  }

  toEntityFromResponse(response) {
    return this.toEntityFromResource(response.data);
  }

  toEntitiesFromResponse(response) {
    if (!Array.isArray(response.data)) {
      throw new Error('invalid-plots-response');
    }
    return response.data.map((resource) => this.toEntityFromResource(resource));
  }
}
