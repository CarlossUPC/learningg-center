/**
 * Documents the JSON representation exchanged with the inspections endpoint.
 * @summary Defines the Inspection API resource shape.
 * @author Alex Rivera
 */

/**
 * @typedef {Object} InspectionResource
 * @property {number} [id]
 * @property {number} plotId
 * @property {string} observations
 * @property {string} recommendedActions
 * @property {'Good'|'Warning'|'Critical'} cropStatus
 * @property {string} inspectionDate
 */
export {};
