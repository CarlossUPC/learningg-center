/**
 * Documents the JSON representation returned by the plots endpoint.
 * @summary Defines the Plot API resource shape.
 * @author Alex Rivera
 */

/**
 * @typedef {Object} PlotResource
 * @property {number} id
 * @property {string} name
 * @property {string} location
 * @property {number} hectares
 * @property {string} monitoringStartDate
 */
export {};
