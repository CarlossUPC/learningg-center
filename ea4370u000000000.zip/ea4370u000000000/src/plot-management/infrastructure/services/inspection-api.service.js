/**
 * Sends new inspections to json-server.
 * @summary Provides the Inspection creation operation.
 * @author Alex Rivera
 */
import { http } from '@/shared/infrastructure/services/http.service.js';
import { InspectionAssembler } from '../assemblers/inspection.assembler.js';

export class InspectionApiService {
  #assembler = new InspectionAssembler();

  async create(inspection) {
    const resource = this.#assembler.toResourceFromEntity(inspection);
    const response = await http.post(import.meta.env.VITE_INSPECTIONS_PATH, resource);
    return this.#assembler.toEntityFromResponse(response);
  }
}
