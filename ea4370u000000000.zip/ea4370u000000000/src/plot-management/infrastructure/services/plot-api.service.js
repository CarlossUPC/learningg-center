/**
 * Requests the plot collection and individual plots from json-server.
 * @summary Provides Plot API operations to the application layer.
 * @author Alex Rivera
 */
import { http } from '@/shared/infrastructure/services/http.service.js';
import { PlotAssembler } from '../assemblers/plot.assembler.js';

export class PlotApiService {
  #assembler = new PlotAssembler();

  async getAll() {
    const response = await http.get(import.meta.env.VITE_PLOTS_PATH);
    return this.#assembler.toEntitiesFromResponse(response);
  }

  async getById(id) {
    const path = import.meta.env.VITE_PLOTS_PATH + '/' + encodeURIComponent(id);
    const response = await http.get(path);
    return this.#assembler.toEntityFromResponse(response);
  }
}
