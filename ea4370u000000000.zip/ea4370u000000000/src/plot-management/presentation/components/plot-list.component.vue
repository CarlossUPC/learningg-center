<script setup>
/**
 * Shows registered plots and guards navigation to future monitoring.
 * @summary Renders the responsive plot data grid.
 * @author Alex Rivera
 */
import { useI18n } from 'vue-i18n';
import { useRouter } from 'vue-router';

defineProps({
  plots: { type: Array, required: true },
  loading: { type: Boolean, default: false }
});

const router = useRouter();
const { t, locale } = useI18n();

function formatHectares(value) {
  return new Intl.NumberFormat(locale.value === 'es' ? 'es-PE' : 'en-US', {
    maximumFractionDigits: 2
  }).format(value);
}

function formatDate(value) {
  const date = new Date(String(value).slice(0, 10) + 'T00:00:00Z');
  if (Number.isNaN(date.getTime())) return String(value);
  return new Intl.DateTimeFormat(
    locale.value === 'es' ? 'es-PE' : 'en-US',
    { dateStyle: 'medium', timeZone: 'UTC' }
  ).format(date);
}

function openRegistration(plot) {
  if (!plot.canRegisterInspection) return;
  router.push({ name: 'inspection-registration', params: { id: plot.id } });
}
</script>

<template>
  <div class="table-shell" role="region" :aria-label="t('plots.title')">
    <pv-data-table
      :value="plots"
      :loading="loading"
      data-key="id"
      striped-rows
      :aria-label="t('plots.title')"
    >
      <template #empty>{{ t('plots.empty') }}</template>
      <template #loading>{{ t('plots.loading') }}</template>

      <pv-column field="id" :header="t('plots.id')" />
      <pv-column field="name" :header="t('plots.name')" />
      <pv-column field="location" :header="t('plots.location')" />
      <pv-column :header="t('plots.hectares')">
        <template #body="{ data }">{{ formatHectares(data.hectares) }}</template>
      </pv-column>
      <pv-column :header="t('plots.monitoringStartDate')">
        <template #body="{ data }">{{ formatDate(data.monitoringStartDate) }}</template>
      </pv-column>
      <pv-column :header="t('plots.actions')">
        <template #body="{ data }">
          <pv-button
            :label="t('plots.registerInspection')"
            icon="pi pi-plus-circle"
            size="small"
            :disabled="!data.canRegisterInspection"
            :title="data.canRegisterInspection ? '' : t('plots.notStarted')"
            :aria-label="t('plots.registerInspection') + ': ' + data.name"
            @click="openRegistration(data)"
          />
        </template>
      </pv-column>
    </pv-data-table>
  </div>
</template>
