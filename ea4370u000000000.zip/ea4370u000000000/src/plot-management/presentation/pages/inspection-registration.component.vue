<script setup>
/**
 * Validates and submits an inspection for the plot named in the route.
 * @summary Renders the inspection registration page and feedback Toasts.
 * @author Alex Rivera
 */
import { computed, onMounted, reactive, ref } from 'vue';
import { useI18n } from 'vue-i18n';
import { useRoute, useRouter } from 'vue-router';
import { useToast } from 'primevue/usetoast';
import { PlotManagementService } from '@/plot-management/application/services/plot-management.service.js';

const route = useRoute();
const router = useRouter();
const toast = useToast();
const { t } = useI18n();
const service = new PlotManagementService();

const form = reactive({
  plotId: Number(route.params.id),
  observations: '',
  recommendedActions: '',
  cropStatus: null
});
const plot = ref(null);
const loading = ref(true);
const saving = ref(false);
const submitted = ref(false);
const pageErrorKey = ref('');

const statusOptions = computed(() => [
  { label: t('status.good'), value: 'Good' },
  { label: t('status.warning'), value: 'Warning' },
  { label: t('status.critical'), value: 'Critical' }
]);
const canSubmit = computed(
  () => Boolean(plot.value?.canRegisterInspection) && !saving.value
);

onMounted(async () => {
  try {
    plot.value = await service.getPlotById(route.params.id);
    if (!plot.value.canRegisterInspection) {
      pageErrorKey.value = 'plots.notStarted';
    }
  } catch (error) {
    pageErrorKey.value = error.message === 'invalid-plot'
      ? 'errors.invalidPlot'
      : 'errors.loadPlots';
  } finally {
    loading.value = false;
  }
});

function showError(messageKey) {
  toast.add({
    severity: 'error',
    summary: t('errors.title'),
    detail: t(messageKey),
    life: 5000
  });
}

async function registerInspection() {
  submitted.value = true;
  if (!canSubmit.value) return;
  if (
    !form.observations.trim() ||
    !form.recommendedActions.trim() ||
    !form.cropStatus
  ) {
    showError('inspection.required');
    return;
  }

  saving.value = true;
  try {
    await service.registerInspection(form);
    if (form.cropStatus === 'Critical') {
      toast.add({
        severity: 'warn',
        summary: t('status.critical'),
        detail: t('inspection.critical'),
        life: 6000
      });
    }
    toast.add({
      severity: 'success',
      summary: t('inspection.title'),
      detail: t('inspection.success'),
      life: 5000
    });
    form.observations = '';
    form.recommendedActions = '';
    form.cropStatus = null;
    submitted.value = false;
  } catch (error) {
    const errorKey = {
      'invalid-plot': 'errors.invalidPlot',
      'not-started': 'plots.notStarted',
      'required-fields': 'inspection.required'
    }[error.message] ?? 'errors.saveFailed';
    showError(errorKey);
  } finally {
    saving.value = false;
  }
}
</script>

<template>
  <section class="surface-card form-card" aria-labelledby="inspection-title">
    <div class="section-heading">
      <div>
        <p class="eyebrow">TEND</p>
        <h1 id="inspection-title">{{ t('inspection.title') }}</h1>
      </div>
      <i class="pi pi-check-square" aria-hidden="true"></i>
    </div>
    <p v-if="loading" role="status">{{ t('plots.loading') }}</p>
    <p v-if="pageErrorKey" class="feedback" role="alert">{{ t(pageErrorKey) }}</p>
    <p v-if="plot" class="plot-name">
      {{ t('inspection.plot') }}: <strong>{{ plot.name }}</strong>
    </p>

    <form
      v-if="!loading && plot?.canRegisterInspection"
      class="inspection-form"
      novalidate
      @submit.prevent="registerInspection"
    >
      <div class="field">
        <label for="plot-id">{{ t('inspection.plotId') }}</label>
        <pv-input-text
          id="plot-id"
          :model-value="String(form.plotId)"
          readonly
          required
          class="w-full"
          aria-readonly="true"
        />
      </div>
      <div class="field">
        <label for="observations">{{ t('inspection.observations') }}</label>
        <pv-textarea
          id="observations"
          v-model="form.observations"
          rows="4"
          auto-resize
          required
          class="w-full"
          :aria-invalid="submitted && !form.observations.trim()"
        />
      </div>
      <div class="field">
        <label for="recommended-actions">{{ t('inspection.recommendedActions') }}</label>
        <pv-textarea
          id="recommended-actions"
          v-model="form.recommendedActions"
          rows="4"
          auto-resize
          required
          class="w-full"
          :aria-invalid="submitted && !form.recommendedActions.trim()"
        />
      </div>
      <div class="field">
        <label for="crop-status">{{ t('inspection.cropStatus') }}</label>
        <pv-select
          id="crop-status"
          v-model="form.cropStatus"
          :options="statusOptions"
          option-label="label"
          option-value="value"
          :placeholder="t('inspection.selectStatus')"
          required
          class="w-full"
          :aria-invalid="submitted && !form.cropStatus"
        />
      </div>
      <div class="form-actions">
        <pv-button
          type="submit"
          icon="pi pi-save"
          :label="saving ? t('inspection.saving') : t('inspection.register')"
          :loading="saving"
          :disabled="!canSubmit"
        />
        <pv-button
          type="button"
          icon="pi pi-arrow-left"
          severity="secondary"
          outlined
          :label="t('nav.backHome')"
          @click="router.push('/home')"
        />
      </div>
    </form>
    <pv-button
      v-else
      type="button"
      icon="pi pi-arrow-left"
      severity="secondary"
      outlined
      :label="t('nav.backHome')"
      @click="router.push('/home')"
    />
  </section>
</template>
