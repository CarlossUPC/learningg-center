<script setup>
/**
 * Loads the registered plots and introduces the Tend application.
 * @summary Renders the Home route.
 * @author Alex Rivera
 */
import { onMounted, ref } from 'vue';
import { useI18n } from 'vue-i18n';
import PlotList from '@/plot-management/presentation/components/plot-list.component.vue';
import { PlotManagementService } from '@/plot-management/application/services/plot-management.service.js';

const { t } = useI18n();
const service = new PlotManagementService();
const plots = ref([]);
const loading = ref(false);
const loadFailed = ref(false);

async function loadPlots() {
  loading.value = true;
  loadFailed.value = false;
  try {
    plots.value = await service.getPlots();
  } catch {
    loadFailed.value = true;
  } finally {
    loading.value = false;
  }
}

onMounted(loadPlots);
</script>

<template>
  <div class="page-stack">
    <section class="hero surface-card" aria-labelledby="home-title">
      <p class="eyebrow">TEND</p>
      <h1 id="home-title">{{ t('home.title') }}</h1>
      <h2>{{ t('home.welcome') }}</h2>
      <p>{{ t('home.intro') }}</p>
    </section>

    <section class="surface-card content-card" aria-labelledby="plots-title">
      <div class="section-heading">
        <h2 id="plots-title">{{ t('plots.title') }}</h2>
        <span class="pi pi-map" aria-hidden="true"></span>
      </div>
      <div v-if="loadFailed" class="feedback" role="alert">
        <p>{{ t('errors.loadPlots') }}</p>
        <pv-button :label="t('plots.retry')" icon="pi pi-refresh" @click="loadPlots" />
      </div>
      <plot-list v-else :plots="plots" :loading="loading" />
    </section>
  </div>
</template>
