/**
 * Defines the application routes and loads each page on demand.
 * @summary Handles Home, inspection registration and unknown paths.
 * @author Alex Rivera
 */
import { createRouter, createWebHistory } from 'vue-router';

const router = createRouter({
  history: createWebHistory(),
  routes: [
    { path: '/', redirect: '/home' },
    {
      path: '/home',
      name: 'home',
      component: () => import('@/public/presentation/pages/home.component.vue')
    },
    {
      path: '/plots/:id/inspections',
      name: 'inspection-registration',
      component: () => import('@/plot-management/presentation/pages/inspection-registration.component.vue')
    },
    {
      path: '/:pathMatch(.*)*',
      name: 'page-not-found',
      component: () => import('@/shared/presentation/pages/page-not-found.component.vue')
    }
  ]
});

export default router;
