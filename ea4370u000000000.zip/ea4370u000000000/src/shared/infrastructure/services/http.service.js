/**
 * Centralizes the Axios configuration for the local API.
 * @summary Supplies a reusable HTTP client to infrastructure services.
 * @author Alex Rivera
 */
import axios from 'axios';

export const http = axios.create({
  baseURL: import.meta.env.VITE_API_BASE_URL,
  timeout: 10000
});
