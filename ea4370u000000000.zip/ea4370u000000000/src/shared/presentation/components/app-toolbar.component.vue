<script setup>
/**
 * Provides the Tend brand, Home navigation and language selector.
 * @summary Renders the shared application toolbar.
 * @author Alex Rivera
 */
import { computed, ref } from 'vue';
import { useI18n } from 'vue-i18n';

const { locale, t } = useI18n();
const logoFailed = ref(false);
const languages = ['EN', 'ES'];

const selectedLanguage = computed({
  get: () => locale.value.toUpperCase(),
  set: (value) => {
    if (!value) return;
    locale.value = value.toLowerCase();
    document.documentElement.lang = locale.value;
  }
});

const logoUrl = computed(() => {
  const base = import.meta.env.VITE_CLEARBIT_LOGO_URL;
  const domain = import.meta.env.VITE_TEND_DOMAIN;
  return base + '/' + domain;
});
</script>

<template>
  <header class="site-header">
    <pv-toolbar class="site-toolbar" :aria-label="t('app.navigation')">
      <template #start>
        <router-link class="brand" to="/home" :aria-label="t('nav.home')">
          <img
            v-if="!logoFailed"
            :src="logoUrl"
            alt="Tend"
            class="brand-logo"
            @error="logoFailed = true"
          />
          <span v-else class="brand-fallback" aria-label="Tend">T</span>
          <span class="brand-title">{{ t('app.tagline') }}</span>
        </router-link>
      </template>
      <template #center>
        <router-link class="home-link" to="/home">{{ t('nav.home') }}</router-link>
      </template>
      <template #end>
        <div class="language-control">
          <span id="language-label" class="sr-only">{{ t('app.language') }}</span>
          <pv-select-button
            v-model="selectedLanguage"
            :options="languages"
            :allow-empty="false"
            aria-labelledby="language-label"
          />
        </div>
      </template>
    </pv-toolbar>
  </header>
</template>
