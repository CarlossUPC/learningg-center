<script setup>
/**
 * Explains an unsupported path and offers a route back to Home.
 * @summary Renders the page-not-found view.
 * @author Alex Rivera
 */
import { useRoute, useRouter } from 'vue-router';
import { useI18n } from 'vue-i18n';

const route = useRoute();
const router = useRouter();
const { t } = useI18n();
</script>

<template>
  <section class="surface-card not-found" aria-labelledby="not-found-title">
    <i class="pi pi-map-marker" aria-hidden="true"></i>
    <h1 id="not-found-title">404</h1>
    <p class="not-found-path">{{ t('errors.notFound', { path: route.fullPath }) }}</p>
    <pv-button
      :label="t('nav.backHome')"
      icon="pi pi-home"
      @click="router.push('/home')"
    />
  </section>
</template>
