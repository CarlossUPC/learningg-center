/**
 * Configures Vue compilation and the source-code alias.
 * @summary Provides the Vite configuration for the Tend application.
 * @author Alex Rivera
 */
import { defineConfig } from 'vite';
import vue from '@vitejs/plugin-vue';
import { fileURLToPath, URL } from 'node:url';

export default defineConfig({
  plugins: [vue()],
  resolve: {
    alias: {
      '@': fileURLToPath(new URL('./src', import.meta.url))
    }
  }
});
